package com.websocket.web;

import javax.servlet.http.HttpSession;
import javax.websocket.HandshakeResponse;
import javax.websocket.server.*;

public class ChatRoomServerConfigurator extends ServerEndpointConfig.Configurator{
	
	@Override
    public void modifyHandshake(ServerEndpointConfig config, HandshakeRequest request, HandshakeResponse response)
    {
        HttpSession httpSession = (HttpSession)request.getHttpSession();
        config.getUserProperties().put("username", (String)httpSession.getAttribute("username").toString());
        config.getUserProperties().put("chatroomname", (String)httpSession.getAttribute("chatroomname").toString());
    }
}
