package com.websocket.web;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonWriter;
import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
@ServerEndpoint(value = "/chatServerEndpoint", configurator = ChatRoomServerConfigurator.class)
public class ChatServerEndpoint {
	int count = 10;
	 private Session userSession;
	static Set<Session> chatRoomUsers = Collections.synchronizedSet(new HashSet<Session>());
	static  HashMap<String, ArrayList<Session>> hm = new HashMap<>();
	@OnOpen
	public void handleOpen(EndpointConfig endpointConfig, Session userSession) {
		ArrayList<Session> roomUsers1 = new ArrayList();
		ArrayList<Session> roomUsers2 = new ArrayList();
		 this.userSession = userSession;
		
		try {
			userSession.getUserProperties().put("username", endpointConfig.getUserProperties().get("username"));
			userSession.getUserProperties().put("chatroomname", endpointConfig.getUserProperties().get("chatroomname"));
			System.out.println("endpointConfig.getUserProperties().get(\"chatroomname\").toString() "+endpointConfig.getUserProperties().get("chatroomname").toString());
			
			String chatRoomName = endpointConfig.getUserProperties().get("chatroomname").toString();
			 if(hm.containsKey(chatRoomName.toString())) {
				 
				 roomUsers1 = hm.get(chatRoomName);
				 
				 for(Session s:roomUsers1) {
					if (s.isOpen()) {
						System.out.println("list: "+s.getUserProperties().get("username"));
						roomUsers2.add(s);
					} else {
					    // handle closed session
					}
				 }
				 
				 roomUsers2.add(userSession);
				 hm.replace(chatRoomName, roomUsers2);
			 }else {
				 roomUsers1.add(userSession);
				 hm.put(chatRoomName, roomUsers1);
			 }
			 chatRoomUsers.add(userSession);
			 System.out.println("chatRoomUsers  from hashmap : "+roomUsers1.size() );
			 
			 System.out.println(""+userSession.getUserProperties().get("username")+" join the chat.");
		   
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	@OnMessage
	public void handleMessage(String message, Session userSession) {
		try {
			ArrayList<Session> roomUsers1 = new ArrayList<Session>();
		String username = (String) userSession.getUserProperties().get("username");
		String chatroomname = (String) userSession.getUserProperties().get("chatroomname");
		System.out.println(" handleMessage chatroomname : "+chatroomname);
		
		roomUsers1 = hm.get(chatroomname);
		String messageMsg =message +" > "+chatroomname;
		if(username!=null) {
			roomUsers1.stream().forEach(x ->{
				try {
					System.out.println("username: "+username);
					x.getBasicRemote().sendText(buildJsonData(username, messageMsg));
					}
				catch (Exception e) {
					e.printStackTrace();
				}
			});
		}else {
			System.out.println("userSession : NOT AVAILABLE");
		}
		
	
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	
		
	}
	
	@OnClose
	public void handleClose(Session userSession) {
		chatRoomUsers.remove(userSession);
		System.out.println(""+userSession.getUserProperties().get("username")+" has left the chat.");
	}
	
	@OnError
	public void handleError(Throwable t) {
		t.printStackTrace();
	}
	private String buildJsonData(String username, String message) {
		StringWriter stringWriter = new StringWriter();
		try {
		JsonObject jsonObject = Json.createObjectBuilder().add("message", username+" :"+message).build();
		try (JsonWriter jsonWriter = Json.createWriter(stringWriter)){
			jsonWriter.write(jsonObject);
		}
		}catch (Exception e) {
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			e.printStackTrace();
		}
		return stringWriter.toString();
	}
}
