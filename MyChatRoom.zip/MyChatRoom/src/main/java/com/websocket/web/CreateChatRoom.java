package com.websocket.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateChatRoom
 */
@WebServlet("/CreateChatRoom")
public class CreateChatRoom extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getSession().getAttribute("chatRoomName")!=null && request.getSession().getAttribute("chatRoomName").toString().equals(request.getParameter("chatroomname").toString())) {
			request.getSession().setAttribute("msg", request.getParameter("chatroomname").toString() + " Room Already Created");
			response.sendRedirect("joinchat.jsp");
		}else {
			request.getSession().setAttribute("chatRoomName", request.getParameter("chatroomname"));
			response.sendRedirect("joinchat.jsp");
		}
	}

}
