package com.websocket.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class UserName
 */
@WebServlet("/UserNameServlet")
public class UserNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		ServletContext context = getServletContext();
		
		HttpSession httpsession = request.getSession(true);
		String username = request.getParameter("username");
		String chatroomname = request.getParameter("chatroomname");
		httpsession.setAttribute("username", username);
		httpsession.setAttribute("chatroomname", chatroomname);
		
		
		
		
		if(username!=null) {
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/chat-room.jsp");
		     rd.forward(request, response);		
		}
		
	}

	
}
